/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.group3.realestatems_g3;

/**
 *
 * @author ACER
 */
public class RealEstateMS_G3 {
  
    public static void main(String[] args) {
        new RealEstateMS_LoginPage();
    }
}