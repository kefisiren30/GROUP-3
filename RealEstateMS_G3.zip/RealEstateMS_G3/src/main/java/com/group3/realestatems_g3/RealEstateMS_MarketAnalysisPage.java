/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group3.realestatems_g3;

import javax.swing.*;

/**
 *
 * @author ACER
 */
public class RealEstateMS_MarketAnalysisPage extends JFrame{
    
    public RealEstateMS_MarketAnalysisPage(){
        initComponents();
        
        //Frame
        setTitle("Real Estate Management System");
        setSize(900, 700);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        
    }
    
}
